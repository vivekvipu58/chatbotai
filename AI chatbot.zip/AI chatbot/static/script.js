/**
 * TravelBot AI — Client-side enhancements
 * Handles: smooth scroll, typing animation, keyboard shortcuts
 */

document.addEventListener("DOMContentLoaded", () => {

    // ── Auto-scroll to bottom of chat ──
    function scrollToBottom() {
        const chatArea = document.querySelector('[data-testid="stChatMessageContainer"]');
        if (chatArea) {
            chatArea.scrollTop = chatArea.scrollHeight;
        }
    }

    // For loop: observe chat mutations and scroll
    const observer = new MutationObserver((mutations) => {
        for (let mutation of mutations) {
            if (mutation.addedNodes.length > 0) {
                scrollToBottom();
            }
        }
    });

    const chatContainer = document.querySelector("main");
    if (chatContainer) {
        observer.observe(chatContainer, { childList: true, subtree: true });
    }

    // ── Keyboard shortcut: Ctrl+K to focus chat input ──
    document.addEventListener("keydown", (e) => {
        if (e.ctrlKey && e.key === "k") {
            e.preventDefault();
            const input = document.querySelector('[data-testid="stChatInput"] textarea');
            if (input) input.focus();
        }
    });

    // ── Animate chat messages on load ──
    const messages = document.querySelectorAll('[data-testid="stChatMessage"]');
    let delay = 0;
    for (let i = 0; i < messages.length; i++) {
        messages[i].style.animationDelay = `${delay}ms`;
        delay += 80;
    }

    scrollToBottom();
    console.log("TravelBot AI client scripts loaded ✈️");
});
